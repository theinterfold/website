The Interfold — logos
=====================

Four formats, three colour variants, SVG only.

  Lockup/          Mark and wordmark side by side. The default.
  Lockup Stacked/  For when horizontal space is tight.
  Wordmark/        Text only, for when the mark is already on the page.
  Symbol/          Mark only, for avatars, favicons and small sizes.

  dark    Default. Light backgrounds like Mint and white.
  signal  Dark backgrounds.
  mint    Dark backgrounds, on the Mint ground.

When in doubt, use the dark mark on Mint.

PNGs, the `pure-white` / `black` / `pure-black` variants, colour swatches,
key visuals and the type list are all in the full kit:

  https://github.com/theinterfold/brand-kit
